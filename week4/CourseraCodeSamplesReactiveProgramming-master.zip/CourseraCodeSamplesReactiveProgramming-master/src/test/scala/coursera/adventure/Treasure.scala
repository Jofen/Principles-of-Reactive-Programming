package coursera.adventure

class Treasure(){}

case class Diamond() extends Treasure {}
